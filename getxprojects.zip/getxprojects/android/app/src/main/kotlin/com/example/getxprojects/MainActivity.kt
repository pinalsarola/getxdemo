package com.example.getxprojects

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
